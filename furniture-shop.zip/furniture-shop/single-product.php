<!-- MASTER HEADER HERE  -->
<?php include ('master-header.php'); 

?>

<?php
  
	$product_shuffle = ($product->getData());

    $item_id = $_GET['item_id'] ?? 1;
    foreach ($product->getData() as $item) :
        if ($item['item_id'] == $item_id) :

	// request method post
	if($_SERVER['REQUEST_METHOD'] == "POST"){
		// if the below add to add button form is submitted 
		if (isset($_POST['single_product_submit'])){
			// call method addToCart
			$Cart->addToCart( $_POST['user_id'],$_POST['item_id']);
		}
	}		
?>
	<body>	
		<!-- WRAPPER START -->
		<div class="wrapper bg-dark-white">
		<!-- HEADER HERE  -->
        <?php include_once('header.php'); ?>
			<!-- PRODUCT-AREA START -->
			<div class="product-area single-pro-area pt-80 pb-80 product-style-2">
				<div class="container">	
					<div class="row shop-list single-pro-info no-sidebar">
						<!-- Single-product start -->
						<div class="col-lg-12">
							<div class="single-product clearfix">
								<!-- Single-pro-slider Big-photo start -->
								<div class="single-pro-slider single-big-photo view-lightbox slider-for">
									<div>
										<!-- large image link start -->
										<img src="<?php echo $item['item_image'] ?? "img/product/1.jpg" ?>" alt="" />
										<a class="view-full-screen" href="img/single-product/large/1.jpg"  data-lightbox="roadtrip" data-title="My caption">
											<i class="zmdi zmdi-zoom-in"></i>
										<!-- large image link ends -->
										</a>
									</div>
									<div>
										<img src="img/single-product/medium/2.jpg" alt="" />
										<a class="view-full-screen" href="img/single-product/large/2.jpg"  data-lightbox="roadtrip" data-title="My caption">
											<i class="zmdi zmdi-zoom-in"></i>
										</a>
									</div>
									<div>
										<img src="img/single-product/medium/3.jpg" alt="" />
										<a class="view-full-screen" href="img/single-product/large/3.jpg"  data-lightbox="roadtrip" data-title="My caption">
											<i class="zmdi zmdi-zoom-in"></i>
										</a>
									</div>
									<div>
										<img src="img/single-product/medium/4.jpg" alt="" />
										<a class="view-full-screen" href="img/single-product/large/4.jpg"  data-lightbox="roadtrip" data-title="My caption">
											<i class="zmdi zmdi-zoom-in"></i>
										</a>
									</div>
									<div>
										<img src="img/single-product/medium/5.jpg" alt="" />
										<a class="view-full-screen" href="img/single-product/large/5.jpg"  data-lightbox="roadtrip" data-title="My caption">
											<i class="zmdi zmdi-zoom-in"></i>
										</a>
									</div>
								</div>	
								<!-- Single-pro-slider Big-photo end -->								
								<div class="product-info">
									<div class="fix">
										<!-- item name from mysql  -->
										<h4 class="post-title floatleft"><?php echo $item['item_name'] ?? "Unknown"; ?></h4>
										<span class="pro-rating floatright">
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star-half"></i></a>
											<a href="#"><i class="zmdi zmdi-star-half"></i></a>
											<span>( 27 Rating )</span>
										</span>
									</div>
									<div class="fix mb-20">
										<!-- price from mysql -->
										<span class="pro-price">$<span><?php echo $item['item_price'] ?? 0; ?></span>
									</div>
									<div class="product-description">
										<p>There are many variations of passages of Lorem Ipsum available, but the majority have be suffered alteration in some form, by injected humou or randomised words which donot look even slightly believable. If you are going to use a passage of Lorem Ipsum. </p>
									</div>
									<!-- color start -->								
									<div class="color-filter single-pro-color mb-20 clearfix">
										<ul>
											<li><span class="color-title text-capitalize">color</span></li>
											<li class="active"><a href="#"><span class="color color-1"></span></a></li>
											<li><a href="#"><span class="color color-2"></span></a></li>
											<li><a href="#"><span class="color color-7"></span></a></li>
											<li><a href="#"><span class="color color-3"></span></a></li>
											<li><a href="#"><span class="color color-4"></span></a></li>
										</ul>
									</div>
									<!-- color end -->
									<!-- Size start -->
									<!-- <div class="size-filter single-pro-size mb-35 clearfix">
										<ul>
											<li><span class="color-title text-capitalize">size</span></li>
											<li><a href="#">M</a></li>
											<li class="active"><a href="#">S</a></li>
											<li><a href="#">L</a></li>
											<li><a href="#">SL</a></li>
											<li><a href="#">XL</a></li>
										</ul>
									</div> -->
									<!-- Size end -->
									<div class="clearfix">
										<!-- <div class="cart-plus-minus">
											<input type="text" value="02" name="qtybutton" class="cart-plus-minus-box">
										</div> -->
										<div class="product-action clearfix">
											<a href="#" data-toggle="tooltip" data-placement="top" title="Wishlist"><i class="zmdi zmdi-favorite-outline"></i></a>
											<!-- <a href="#" data-toggle="modal"  data-target="#productModal" title="Quick View"><i class="zmdi zmdi-zoom-in"></i></a> -->
											<!-- <a href="#" data-toggle="tooltip" data-placement="top" title="Compare"><i class="zmdi zmdi-refresh"></i></a> -->
											<!--use my sql to make add cart button -->
											<form method="post">
												<input type="hidden" name="item_id" value="<?php echo $item['item_id'] ?? '1'; ?>">
												<input type="hidden" name="user_id" value="<?php echo 1; ?>">
												
														<?php
														if (in_array($item['item_id'], $Cart->getCartId($product->getData('cart')) ?? [])){
															echo '<button type="submit" class="button"><a href="#" data-toggle="tooltip" data-placement="top" title="In The Cart"><i class="zmdi zmdi-check"></i></a></button>';
														}else{
															echo '<button type="submit" name="single_product_submit" class="button" ><a href="#" data-toggle="tooltip" data-placement="top" title="Add To Cart"><i class="zmdi zmdi-shopping-cart-plus"></i></a></button>';
														}
														?>
											<!-- <a href="#" data-toggle="tooltip" data-placement="top" title="Add To Cart"><i class="zmdi zmdi-shopping-cart-plus"></i></a> -->
											</form>
											
										</div>
									</div>
									<!-- Single-pro-slider Small-photo start -->
									<!-- <div class="single-pro-slider single-sml-photo slider-nav">
										<div>
											<img src="img/single-product/small/1.jpg" alt="" />
										</div>
										<div>
											<img src="img/single-product/small/2.jpg" alt="" />
										</div>
										<div>
											<img src="img/single-product/small/3.jpg" alt="" />
										</div>
										<div>
											<img src="img/single-product/small/4.jpg" alt="" />
										</div>
										<div>
											<img src="img/single-product/small/5.jpg" alt="" />
										</div>
									</div> -->
									<!-- Single-pro-slider Small-photo end -->
								</div>
							</div>
						</div>
						<!-- Single-product end -->
					</div>
					<!-- single-product-tab start -->
					<div class="single-pro-tab">
						<div class="row">
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
								<div class="single-pro-tab-menu">
									<!-- Nav tabs -->
									

					<?php
							endif;
							endforeach;
					?>

					<!-- single-product-tab end -->
				</div>
			</div>
			<!-- PRODUCT-AREA END -->
			<!-- FOOTER BY PHP LINK  -->
            <?php include_once('footer.php'); ?>
			
		</div>
		<!-- WRAPPER END -->

		<!-- all js here -->
		<!-- jquery latest version -->
		<script src="js/vendor/jquery-1.12.0.min.js"></script>
		<!-- bootstrap js -->
		<script src="js/bootstrap.min.js"></script>
		<!-- jquery.meanmenu js -->
		<script src="js/jquery.meanmenu.js"></script>
		<!-- slick.min js -->
		<script src="js/slick.min.js"></script>
		<!-- jquery.treeview js -->
		<script src="js/jquery.treeview.js"></script>
		<!-- lightbox.min js -->
		<script src="js/lightbox.min.js"></script>
		<!-- jquery-ui js -->
		<script src="js/jquery-ui.min.js"></script>
		<!-- jquery.nivo.slider js -->
		<script src="lib/js/jquery.nivo.slider.js"></script>
		<script src="lib/home.js"></script>
		<!-- jquery.nicescroll.min js -->
		<script src="js/jquery.nicescroll.min.js"></script>
		<!-- countdon.min js -->
		<script src="js/countdon.min.js"></script>
		<!-- wow js -->
		<script src="js/wow.min.js"></script>
		<!-- plugins js -->
		<script src="js/plugins.js"></script>
		<!-- main js -->
		<script src="js/main.js"></script>
	</body>
</html>
