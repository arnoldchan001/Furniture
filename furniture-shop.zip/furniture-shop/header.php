	
    <!doctype html>	
    <!-- Mobile-header-top Start -->
    <div class="mobile-header-top hidden-lg hidden-md hidden-sm">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<!-- header-search-mobile start -->
							<div class="header-search-mobile">
								<div class="table">
									<div class="table-cell">
										<ul>
											<li><a class="search-open" href="#"><i class="zmdi zmdi-search"></i></a></li>
											<li><a href="login.php"><i class="zmdi zmdi-lock"></i></a></li>
											<li><a href="my-account.php"><i class="zmdi zmdi-account"></i></a></li>
											<li><a href="wishlist.php"><i class="zmdi zmdi-favorite"></i></a></li>
										</ul>
									</div>
								</div>
							</div>
							<!-- header-search-mobile start -->
						</div>
					</div>
				</div>
			</div>
			<!-- Mobile-header-top End -->
			<!-- HEADER-AREA START -->
			<header id="sticky-menu" class="header"  >
				<div class="header-area">
					<div class="container-fluid">
						<div class="row">
							<div class="col-sm-4 col-sm-offset-4 col-xs-7">
								<div class="logo text-center">
									<a href="index.php"><img src="img/logo/CARP_Logo.png" alt=""/></a>
								</div>
							</div>
							<div class="col-sm-4 col-xs-5">
								<div class="mini-cart text-right">
									<ul>
										<li>
											<a class="cart-icon" href="cart.php">
												<i class="zmdi zmdi-shopping-cart"></i>
												<span><?php echo count($product->getData('cart')); ?></span>
											</a>

											<div class="mini-cart-brief text-left">
												<div class="cart-items">
													<p class="mb-0">You have <span><?php echo count($product->getData('cart')); ?> items</span> in your shopping bag</p>
												</div>
												<!-- <div class="all-cart-product clearfix">
													<div class="single-cart clearfix">
														<div class="cart-photo">
															<a href="#"><img src="img/cart/1.jpg" alt="" /></a>
														</div>
														<div class="cart-info">
															<h5><a href="#">dummy product name</a></h5>
															<p class="mb-0">Price : $ 100.00</p>
															<p class="mb-0">Qty : 02 </p>
															<span class="cart-delete"><a href="#"><i class="zmdi zmdi-close"></i></a></span>
														</div>
													</div>
													<div class="single-cart clearfix">
														<div class="cart-photo">
															<a href="#"><img src="img/cart/2.jpg" alt="" /></a>
														</div>
														<div class="cart-info">
															<h5><a href="#">dummy product name</a></h5>
															<p class="mb-0">Price : $ 300.00</p>
															<p class="mb-0">Qty : 01 </p>
															<span class="cart-delete"><a href="#"><i class="zmdi zmdi-close"></i></a></span>
														</div>
													</div>
												</div> -->
												<!-- <div class="cart-totals">
													<h5 class="mb-0">Total <span class="floatright">$500.00</span></h5>
												</div> -->
												<div class="cart-bottom  clearfix">
													<a href="cart.php" class="button-one  text-center text-uppercase" data-text="View cart">View cart</a>
													<a href="cart.php" class="button-one floatright text-uppercase" data-text="Check out">Check out</a>
												</div>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- MAIN-MENU START -->
				<div class="menu-toggle hamburger hamburger--emphatic hidden-xs">
					<div class="hamburger-box">
						<div class="hamburger-inner"></div>
					</div>
				</div>
				<div class="main-menu  hidden-xs">
					<nav>
						<ul>
							<li><a href="index.php">home</a></li>
							<li><a href="shop.php">shop</a></li>
							<!-- <li><a href="blog.php">blog</a></li> -->
							<li><a href="about.php">about us</a></li>
							<li><a href="contact.php">contact</a></li>
							<li><a href="#">pages for admin</a>
								<div class="sub-menu menu-scroll">
									<ul>
										<li class="menu-title">Page's</li>
										<li><a href="shop.php">Shop</a></li>
										<li><a href="single-product.php">Single Product</a></li>
										<li><a href="cart.php">Shopping Cart</a></li>
										<li><a href="wishlist.php">Wishlist</a></li>
										<li><a href="checkout.php">Checkout</a></li>
										<li><a href="order.php">Order</a></li>
										<li><a href="login.php">login / Registration</a></li>
										<li><a href="my-account.php">My Account</a></li>
										<li><a href="404.php">404</a></li>
										<li><a href="blog.php">Blog</a></li>
										<li><a href="single-blog.php">Single Blog</a></li>
										<li><a href="about.php">About Us</a></li>
										<li><a href="contact.php">Contact</a></li>
									</ul>
								</div>
							</li>
							
						</ul>
					</nav>
				</div>
				<!-- MAIN-MENU END -->
			</header>
			<!-- HEADER-AREA END -->
			<!-- Mobile-menu start -->
			<div class="mobile-menu-area">
				<div class="container-fluid">
					<div class="row">
						<div class="col-xs-12 hidden-lg hidden-md hidden-sm">
							<div class="mobile-menu">
								<nav id="dropdown">
									<ul>
										<li><a href="index.php">home</a></li>
										<li><a href="shop.php">products</a></li>
										<li><a href="shop.php">accesories</a></li>
										<li><a href="shop.php">lookbook</a></li>
										<li><a href="blog.php">blog</a></li>
										<li><a href="#">pages</a>
											<ul>
												<li><a href="shop.php">Shop</a></li>
												<li><a href="single-product.php">Single Product</a></li>
												<li><a href="cart.php">Shopping Cart</a></li>
												<li><a href="wishlist.php">Wishlist</a></li>
												<li><a href="checkout.php">Checkout</a></li>
												<li><a href="order.php">Order</a></li>
												<li><a href="login.php">login / Registration</a></li>
												<li><a href="my-account.php">My Account</a></li>
												<li><a href="404.php">404</a></li>
												<li><a href="blog.php">Blog</a></li>
												<li><a href="single-blog.php">Single Blog</a></li>
												<li><a href="about.php">About Us</a></li>
												<li><a href="contact.php">Contact</a></li>
											</ul>
										</li>
										<li><a href="about.php">about us</a></li>
										<li><a href="contact.php">contact</a></li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Mobile-menu end -->
            </html>