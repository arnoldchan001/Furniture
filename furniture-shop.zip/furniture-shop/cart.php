<!-- MASTER HEADER HERE  -->


<?php include ('master-header.php'); 
ob_start();
?>
<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        if (isset($_POST['delete-cart-submit'])){
			
            $deletedrecord = $Cart->deleteCart($_POST['item_id']);
		}
		//save for later 
		if (isset($_POST['wishlist-submit'])){  
			$Cart->saveForLater($_POST['item_id']);
		}
	}

?>

	<body>	
		<!-- WRAPPER START -->
		<div class="wrapper bg-dark-white">

		<!-- HEADER HERE  -->
		<?php include_once('header.php'); ?>
			<!-- SHOPPING-CART-AREA START -->
			<div class="shopping-cart-area  pt-80 pb-80">
				<div class="container">	
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="shopping-cart">
								<!-- Nav tabs -->
								<ul class="cart-page-menu row clearfix mb-30">
									<li class="active"><a href="#shopping-cart" data-toggle="tab">shopping cart</a></li>
									<li><a href="#wishlist" data-toggle="tab">wishlist</a></li>
									<li><a href="#check-out" data-toggle="tab">check out</a></li>
									<li><a href="#order-complete" data-toggle="tab">order complete</a></li>
								</ul>

								<!-- Tab panes -->
								<div class="tab-content">
									<!-- shopping-cart start -->
									<div class="tab-pane active" id="shopping-cart">
										
											<div class="shop-cart-table">
												<div class="table-content table-responsive">
													<table>
														<thead>
															<tr>
																<th class="product-thumbnail">Product</th>
																<th class="product-price">Price</th>
																<th class="product-quantity">Quantity</th>
																<th class="product-subtotal">Total</th>
																<th>Save for later</th>
																<th class="product-remove">Remove</th>
																
															</tr>
														</thead>
														<tbody>
													<?php
													
													foreach ($product->getData('cart') as $item) :
														
														$cart= $product->getProduct($item['item_id']); 
													
														$subTotal[] = array_map(function($item){ // array map function starts 
														
													?>
															<tr class= "cart info">
																<td class="product-thumbnail  text-left">
																	<!-- Single-product start -->
																	<div class="single-product">
																		<div class="product-img">
																			<a href="single-product.php"><img src="<?php echo $item['item_image'] ?? "img/product/1.jpg" ?>" alt="" /></a>
																		</div>
																		<div class="product-info">
																			<h4 class="post-title"><a class="text-light-black" href="#"><?php echo $item['item_name'] ?? "Unknown"; ?></a></h4>
																			<p class="mb-0">Color :  Black</p>
																			<p class="mb-0">Size :     SL</p>
																		</div>
																	</div>
																	<!-- Single-product end -->												
																</td>
																<td class="product-price">$<?php echo $item['item_price'] ?? "Unknown"; ?></td>
																<td class="product-quantity">
																	<div class="cart-plus-minus">
																		<input type="text" value="1" data-id="<?php echo $item['item_id'] ?? '0'; ?>"name="qtybutton" class="cart-plus-minus-box">
																	</div>
																</td>
																<td class="product-subtotal"><?php echo $item['item_price'] ?? "Unknown"; ?></td>
																
																<!-- Wishlist Submit -->
																<td class="save-for-later">
																<form method="post"> 
																		<input type="hidden" value="<?php echo $item['item_id'] ?? 0; ?>" name="item_id">
																		<button type="submit" name="wishlist-submit" class="button"><a href="#"  title="Wishlist"><i class="zmdi zmdi-favorite-outline"></i></a></button>
												
																</form>
																	
																</td>

																<!-- Remove Products  -->
																<td class="product-remove">
																
																<form method="post">
																		<input type="hidden" value="<?php echo $item['item_id'] ?? 0; ?>" name="item_id">
																		<button type="submit" name="delete-cart-submit" class="button"><i class="zmdi zmdi-close"></i></button>
												
																</form>
																</td>
															</tr>
														<?php
															return $item['item_price'];
														},$cart); // array map function ends 
													
														endforeach;
														
														
														?>
															
														</tbody>
													</table>
												</div>
											</div>
											<div class="row">
												<div class="col-md-6 col-sm-6 col-xs-12">
													<div class="customer-login mt-30">
														<h4 class="title-1 title-border text-uppercase">coupon discount</h4>
														<p class="text-gray">Enter your coupon code if you have one!</p>
														<input type="text" placeholder="Enter your code here.">
														<button type="submit" data-text="apply coupon" class="button-one submit-button mt-15">apply coupon</button>
													</div>
												</div>
												<div class="col-md-6 col-sm-6 col-xs-12">
													<div class="customer-login payment-details mt-30">
														<h4 class="title-1 title-border text-uppercase">payment details</h4>
														<table>
															<tbody>
																<tr>
																	<td class="text-left">Order Total</td>
													
																	<td class="text-right">
																		<div class = "cart-subtotal">
																			<?php echo isset($subTotal) ? $Cart->getSum($subTotal) : 0; ?>
																		</div>
																	</td>
																</tr>
															
															</tbody>
														</table>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-12">
													<div class="customer-login mt-30">
														<h4 class="title-1 title-border text-uppercase">culculate shipping</h4>
														<p class="text-gray">Enter your coupon code if you have one!</p>
														<div class="row">
															<div class="col-md-4 col-sm-4 col-xs-12">
																<input type="text" placeholder="Country">
															</div>
															<div class="col-md-4 col-sm-4 col-xs-12">
																<input type="text" placeholder="Region / State">
															</div>
															<div class="col-md-4 col-sm-4 col-xs-12">
																<input type="text" placeholder="Post code">
															</div>
														</div>
														<button type="submit" data-text="get a quote" class="button-one submit-button mt-15">get a quote</button>
													</div>											
												</div>
											</div>
											
									</div>
									<!-- shopping-cart end -->


									<?php include_once('template/_wishlist_template.php'); ?>
							
									<!-- check-out start -->
									<div class="tab-pane" id="check-out">
										<form action="#">
											<div class="shop-cart-table check-out-wrap">
												<div class="row">
													<div class="col-md-6 col-sm-6 col-xs-12">
														<div class="billing-details pr-20">
															<h4 class="title-1 title-border text-uppercase mb-30">billing details</h4>
															<input type="text" placeholder="Your name here...">
															<input type="text" placeholder="Email address here...">
															<input type="text" placeholder="Phone here...">
															<input type="text" placeholder="Company neme here...">
															<select class="custom-select mb-15">
																<option>Contry</option>
																<option>Bangladesh</option>
																<option>United States</option>
																<option>united Kingdom</option>
																<option>Australia</option>
																<option>Canada</option>
															</select>
															<select class="custom-select mb-15">
																<option>State</option>
																<option>Dhaka</option>
																<option>New York</option>
																<option>London</option>
																<option>Melbourne</option>
																<option>Ottawa</option>
															</select>
															<select class="custom-select mb-15">
																<option>Town / City</option>
																<option>Dhaka</option>
																<option>New York</option>
																<option>London</option>
																<option>Melbourne</option>
																<option>Ottawa</option>
															</select>
															<textarea class="custom-textarea" placeholder="Your address here..." ></textarea>
														</div>
													</div>
													<div class="col-md-6 col-sm-6 col-xs-12 mt-xs-30">
														<div class="billing-details pl-20">
															<h4 class="title-1 title-border text-uppercase mb-30">ship to different address</h4>
															<input type="text" placeholder="Your name here...">
															<input type="text" placeholder="Email address here...">
															<input type="text" placeholder="Phone here...">
															<input type="text" placeholder="Company neme here...">
															<select class="custom-select mb-15">
																<option>Contry</option>
																<option>Bangladesh</option>
																<option>United States</option>
																<option>united Kingdom</option>
																<option>Australia</option>
																<option>Canada</option>
															</select>
															<select class="custom-select mb-15">
																<option>State</option>
																<option>Dhaka</option>
																<option>New York</option>
																<option>London</option>
																<option>Melbourne</option>
																<option>Ottawa</option>
															</select>
															<select class="custom-select mb-15">
																<option>Town / City</option>
																<option>Dhaka</option>
																<option>New York</option>
																<option>London</option>
																<option>Melbourne</option>
																<option>Ottawa</option>
															</select>
															<textarea class="custom-textarea" placeholder="Your address here..." ></textarea>
														</div>
													</div>
													<div class="col-md-6 col-sm-6 col-xs-12">
														<div class="our-order payment-details mt-60 pr-20">
															<h4 class="title-1 title-border text-uppercase mb-30">our order</h4>
															<table>
																<thead>
																	<tr>
																		<th><strong>Product</strong></th>
																		<th class="text-right"><strong>Total</strong></th>
																	</tr>
																</thead>
																<tbody>
																	<tr>
																		<td>Dummy Product Name  x 2</td>
																		<td class="text-right">$86.00</td>
																	</tr>
																	<tr>
																		<td>Dummy Product Name  x 1</td>
																		<td class="text-right">$69.00</td>
																	</tr>
																	<tr>
																		<td>Cart Subtotal</td>
																		<td class="text-right">$155.00</td>
																	</tr>
																	<tr>
																		<td>Shipping and Handing</td>
																		<td class="text-right">$15.00</td>
																	</tr>
																	<tr>
																		<td>Vat</td>
																		<td class="text-right">$00.00</td>
																	</tr>
																	<tr>
																		<td>Order Total</td>
																		<td class="text-right">$170.00</td>
																	</tr>
																</tbody>
															</table>
														</div>
													</div>
													<!-- payment-method -->
													<div class="col-md-6 col-sm-6 col-xs-12">
														<div class="payment-method mt-60  pl-20">
															<h4 class="title-1 title-border text-uppercase mb-30">payment method</h4>
															<div class="payment-accordion">
																<!-- Accordion start  -->
																<h3 class="payment-accordion-toggle active">Direct Bank Transfer</h3>
																<div class="payment-content default">
																	<p>Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won't be shipped until the funds have cleared in our account.</p>
																</div> 
																<!-- Accordion end -->
																<!-- Accordion start -->
																<h3 class="payment-accordion-toggle">Cheque Payment</h3>
																<div class="payment-content">
																	<p>Please send your cheque to Store Name, Store Street, Store Town, Store State / County, Store Postcode.</p>
																</div>
																<!-- Accordion end -->
																<!-- Accordion start -->
																<h3 class="payment-accordion-toggle">PayPal</h3>
																<div class="payment-content">
																	<p>Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.</p>
																	<a href="#"><img src="img/payment/1.png" alt="" /></a>
																	<a href="#"><img src="img/payment/2.png" alt="" /></a>
																	<a href="#"><img src="img/payment/3.png" alt="" /></a>
																	<a href="#"><img src="img/payment/4.png" alt="" /></a>
																</div>
																<!-- Accordion end --> 
																<button class="button-one submit-button mt-15" data-text="place order" type="submit">place order</button>			
															</div>															
														</div>
													</div>
												</div>
											</div>
										</form>											
									</div>
									<!-- check-out end -->
									<!-- order-complete start -->
									<div class="tab-pane" id="order-complete">
										<form action="#">
											<div class="thank-recieve bg-white mb-30">
												<p>Thank you. Your order has been received.</p>
											</div>
											<div class="order-info bg-white text-center clearfix mb-30">
												<div class="single-order-info">
													<h4 class="title-1 text-uppercase text-light-black mb-0">order no</h4>
													<p class="text-uppercase text-light-black mb-0"><strong>m 2653257</strong></p>
												</div>
												<div class="single-order-info">
													<h4 class="title-1 text-uppercase text-light-black mb-0">Date</h4>
													<p class="text-uppercase text-light-black mb-0"><strong>june 15, 2017</strong></p>
												</div>
												<div class="single-order-info">
													<h4 class="title-1 text-uppercase text-light-black mb-0">Total</h4>
													<p class="text-uppercase text-light-black mb-0"><strong>$ 170.00</strong></p>
												</div>
												<div class="single-order-info">
													<h4 class="title-1 text-uppercase text-light-black mb-0">payment method</h4>
													<p class="text-uppercase text-light-black mb-0"><a href="#"><strong>check payment</strong></a></p>
												</div>
											</div>
											<div class="shop-cart-table check-out-wrap">
												<div class="row">
													<div class="col-md-6 col-sm-6 col-sm-12">
														<div class="our-order payment-details pr-20">
															<h4 class="title-1 title-border text-uppercase mb-30">our order</h4>
															<table>
																<thead>
																	<tr>
																		<th><strong>Product</strong></th>
																		<th class="text-right"><strong>Total</strong></th>
																	</tr>
																</thead>
																<tbody>
																	<tr>
																		<td>Dummy Product Name  x 2</td>
																		<td class="text-right">$86.00</td>
																	</tr>
																	<tr>
																		<td>Dummy Product Name  x 1</td>
																		<td class="text-right">$69.00</td>
																	</tr>
																	<tr>
																		<td>Cart Subtotal</td>
																		<td class="text-right">$155.00</td>
																	</tr>
																	<tr>
																		<td>Shipping and Handing</td>
																		<td class="text-right">$15.00</td>
																	</tr>
																	<tr>
																		<td>Vat</td>
																		<td class="text-right">$00.00</td>
																	</tr>
																	<tr>
																		<td>Order Total</td>
																		<td class="text-right">$170.00</td>
																	</tr>
																</tbody>
															</table>
														</div>
													</div>
													<!-- payment-method -->
													<div class="col-md-6 col-sm-6 col-sm-12 mt-xs-30">
														<div class="payment-method  pl-20">
															<h4 class="title-1 title-border text-uppercase mb-30">payment method</h4>
															<div class="payment-accordion">
																<!-- Accordion start  -->
																<h3 class="payment-accordion-toggle active">Direct Bank Transfer</h3>
																<div class="payment-content default">
																	<p>Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won't be shipped until the funds have cleared in our account.</p>
																</div> 
																<!-- Accordion end -->
																<!-- Accordion start -->
																<h3 class="payment-accordion-toggle">Cheque Payment</h3>
																<div class="payment-content">
																	<p>Please send your cheque to Store Name, Store Street, Store Town, Store State / County, Store Postcode.</p>
																</div>
																<!-- Accordion end -->
																<!-- Accordion start -->
																<h3 class="payment-accordion-toggle">PayPal</h3>
																<div class="payment-content">
																	<p>Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.</p>
																	<a href="#"><img src="img/payment/1.png" alt="" /></a>
																	<a href="#"><img src="img/payment/2.png" alt="" /></a>
																	<a href="#"><img src="img/payment/3.png" alt="" /></a>
																	<a href="#"><img src="img/payment/4.png" alt="" /></a>
																</div>
																<!-- Accordion end --> 
																<button class="button-one submit-button mt-15" data-text="place order" type="submit">place order</button>			
															</div>															
														</div>
													</div>
												</div>
											</div>
										</form>										
									</div>
									<!-- order-complete end -->
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- SHOPPING-CART-AREA END -->
		<!-- FOOTER BY PHP LINK  -->
		<?php include_once('footer.php'); ?>
			<!-- QUICKVIEW PRODUCT -->
			<div id="quickview-wrapper">
			   <!-- Modal -->
			   <div class="modal fade" id="productModal" tabindex="-1" role="dialog">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							</div>
							<div class="modal-body">
								<div class="modal-product">
									<div class="product-images">
										<div class="main-image images">
											<img alt="#" src="img/product/quickview-photo.jpg"/>
										</div>
									</div><!-- .product-images -->

									<div class="product-info">
										<h1>Aenean eu tristique</h1>
										<div class="price-box-3">
											<hr />
											<div class="s-price-box">
												<span class="new-price">$160.00</span>
												<span class="old-price">$190.00</span>
											</div>
											<hr />
										</div>
										<a href="shop.php" class="see-all">See all features</a>
										<div class="quick-add-to-cart">
											<form method="post" class="cart">
												<div class="numbers-row">
													<input type="number" id="french-hens" value="3">
												</div>
												<button class="single_add_to_cart_button" type="submit">Add to cart</button>
											</form>
										</div>
										<div class="quick-desc">
											Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero.
										</div>
										<div class="social-sharing">
											<div class="widget widget_socialsharing_widget">
												<h3 class="widget-title-modal">Share this product</h3>
												<ul class="social-icons">
													<li><a target="_blank" title="Google +" href="#" class="gplus social-icon"><i class="zmdi zmdi-google-plus"></i></a></li>
													<li><a target="_blank" title="Twitter" href="#" class="twitter social-icon"><i class="zmdi zmdi-twitter"></i></a></li>
													<li><a target="_blank" title="Facebook" href="#" class="facebook social-icon"><i class="zmdi zmdi-facebook"></i></a></li>
													<li><a target="_blank" title="LinkedIn" href="#" class="linkedin social-icon"><i class="zmdi zmdi-linkedin"></i></a></li>
												</ul>
											</div>
										</div>
									</div><!-- .product-info -->
								</div><!-- .modal-product -->
							</div><!-- .modal-body -->
						</div><!-- .modal-content -->
					</div><!-- .modal-dialog -->
			   </div>
			   <!-- END Modal -->
			</div>
			<!-- END QUICKVIEW PRODUCT -->	
			
		</div>
		<!-- WRAPPER END -->
		<?php include_once('footer.php'); ?>
		<?php include_once('master-footer.php'); ?>


 </html>	

