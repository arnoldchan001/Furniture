<?php

shuffle($product_shuffle); 
?>

<!-- PRODUCT-AREA START -->
<div class="product-area pt-80 pb-35">
				<div class="container">
					<!-- Section-title start -->
					<div class="row">
						<div class="col-lg-12">
							<div class="section-title text-center">
								<h2 class="title-border">Featured Products</h2>
							</div>
						</div>
					</div>
					<!-- Section-title end -->
					<div class="row cus-row-30">
						<div class="product-slider arrow-left-right">
						
						<?php 

						foreach ($product_shuffle as $item) { ?>
							<!-- Single-product start -->
							<div class="single-product col-lg-12">
								<div class="product-img">
									<span class="pro-label new-label">new</span>
									<a href="<?php printf('%s?item_id=%s', 'single-product.php',  $item['item_id']); ?>"><img src="<?php echo $item['item_image'] ; ?>" alt="" /></a>
									
								</div>
								<div class="product-info clearfix">
									<div class="fix">
										<h4 class="post-title floatleft"><a href="<?php printf('%s?item_id=%s', 'single-product.php',  $item['item_id']); ?>"><?php echo  $item['item_name'] ?? "Unknown";  ?></a></h4>
										<p class="floatright hidden-sm hidden-xs">Furniture</p>
									</div>
									<div class="fix">
										<span class="pro-price floatleft">$<?php echo $item['item_price'] ?? '0' ; ?></span>
										<span class="pro-rating floatright">
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star-half"></i></a>
											<a href="#"><i class="zmdi zmdi-star-half"></i></a>
										</span>
									</div>
								</div>
							</div>

							<?php } // closing foreach function ?>
							<!-- Single-product end -->

							
							<!-- Single-product start -->
							<!-- <div class="single-product col-lg-12">
								<div class="product-img">
									<span class="pro-label sale-label">Sale</span>
									<a href="single-product.php"><img src="img/product/2.jpg" alt="" /></a>
									<div class="product-action clearfix">
										<a href="#" data-toggle="tooltip" data-placement="top" title="Wishlist"><i class="zmdi zmdi-favorite-outline"></i></a>
										<a href="#" data-toggle="modal"  data-target="#productModal" title="Quick View"><i class="zmdi zmdi-zoom-in"></i></a>
										<a href="#" data-toggle="tooltip" data-placement="top" title="Compare"><i class="zmdi zmdi-refresh"></i></a>
										<a href="#" data-toggle="tooltip" data-placement="top" title="Add To Cart"><i class="zmdi zmdi-shopping-cart-plus"></i></a>
									</div>
								</div>
								<div class="product-info clearfix">
									<div class="fix">
										<h4 class="post-title floatleft"><a href="#">dummy Product name</a></h4>
										<p class="floatright hidden-sm hidden-xs">Furniture</p>
									</div>
									<div class="fix">
										<span class="pro-price floatleft">$ 56.20</span>
										<span class="pro-rating floatright">
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star-half"></i></a>
											<a href="#"><i class="zmdi zmdi-star-half"></i></a>
										</span>
									</div>
								</div>
							</div> -->
							<!-- Single-product end -->
							<!-- Single-product start -->
							<!-- <div class="single-product col-lg-12">
								<div class="product-img">
									<a href="single-product.php"><img src="img/product/3.jpg" alt="" /></a>
									<div class="product-action clearfix">
										<a href="#" data-toggle="tooltip" data-placement="top" title="Wishlist"><i class="zmdi zmdi-favorite-outline"></i></a>
										<a href="#" data-toggle="modal"  data-target="#productModal" title="Quick View"><i class="zmdi zmdi-zoom-in"></i></a>
										<a href="#" data-toggle="tooltip" data-placement="top" title="Compare"><i class="zmdi zmdi-refresh"></i></a>
										<a href="#" data-toggle="tooltip" data-placement="top" title="Add To Cart"><i class="zmdi zmdi-shopping-cart-plus"></i></a>
									</div>
								</div>
								<div class="product-info clearfix">
									<div class="fix">
										<h4 class="post-title floatleft"><a href="#">dummy Product name</a></h4>
										<p class="floatright hidden-sm hidden-xs">Furniture</p>
									</div>
									<div class="fix">
										<span class="pro-price floatleft">$ 56.20</span>
										<span class="pro-rating floatright">
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star-half"></i></a>
											<a href="#"><i class="zmdi zmdi-star-half"></i></a>
										</span>
									</div>
								</div>
							</div> -->
							<!-- Single-product end -->
							<!-- Single-product start -->
							<!-- <div class="single-product col-lg-12">
								<div class="product-img">
									<a href="single-product.php"><img src="img/product/4.jpg" alt="" /></a>
									<div class="product-action clearfix">
										<a href="#" data-toggle="tooltip" data-placement="top" title="Wishlist"><i class="zmdi zmdi-favorite-outline"></i></a>
										<a href="#" data-toggle="modal"  data-target="#productModal" title="Quick View"><i class="zmdi zmdi-zoom-in"></i></a>
										<a href="#" data-toggle="tooltip" data-placement="top" title="Compare"><i class="zmdi zmdi-refresh"></i></a>
										<a href="#" data-toggle="tooltip" data-placement="top" title="Add To Cart"><i class="zmdi zmdi-shopping-cart-plus"></i></a>
									</div>
								</div>
								<div class="product-info clearfix">
									<div class="fix">
										<h4 class="post-title floatleft"><a href="#">dummy Product name</a></h4>
										<p class="floatright hidden-sm hidden-xs">Furniture</p>
									</div>
									<div class="fix">
										<span class="pro-price floatleft">$ 56.20</span>
										<span class="pro-rating floatright">
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star-half"></i></a>
											<a href="#"><i class="zmdi zmdi-star-half"></i></a>
										</span>
									</div>
								</div>
							</div> -->
							<!-- Single-product end -->
							<!-- Single-product start -->
							<!-- <div class="single-product col-lg-12">
								<div class="product-img">
									<span class="pro-label new-label">new</span>
									<a href="single-product.php"><img src="img/product/3.jpg" alt="" /></a>
									<div class="product-action clearfix">
										<a href="#" data-toggle="tooltip" data-placement="top" title="Wishlist"><i class="zmdi zmdi-favorite-outline"></i></a>
										<a href="#" data-toggle="modal"  data-target="#productModal" title="Quick View"><i class="zmdi zmdi-zoom-in"></i></a>
										<a href="#" data-toggle="tooltip" data-placement="top" title="Compare"><i class="zmdi zmdi-refresh"></i></a>
										<a href="#" data-toggle="tooltip" data-placement="top" title="Add To Cart"><i class="zmdi zmdi-shopping-cart-plus"></i></a>
									</div>
								</div>
								<div class="product-info clearfix">
									<div class="fix">
										<h4 class="post-title floatleft"><a href="#">dummy Product name</a></h4>
										<p class="floatright hidden-sm hidden-xs">Furniture</p>
									</div>
									<div class="fix">
										<span class="pro-price floatleft">$ 56.20</span>
										<span class="pro-rating floatright">
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star"></i></a>
											<a href="#"><i class="zmdi zmdi-star-half"></i></a>
											<a href="#"><i class="zmdi zmdi-star-half"></i></a>
										</span>
									</div>
								</div>
							</div> -->
							<!-- Single-product end -->
						</div>
					</div>
				</div>
			</div>
			<!-- PRODUCT-AREA END -->