    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        if (isset($_POST['delete-cart-submit'])){
            
            $deletedrecord = $Cart->deleteCart($_POST['item_id'],'wishlist');
        }
        // Add back to cart 
        if (isset($_POST['cart-submit'])){  
            $Cart->saveForLater($_POST['item_id'],'cart','wishlist'); 
        }
    }
    ?>
					
    <!-- wishlist start -->
    <div class="tab-pane" id="wishlist">
       
            <div class="shop-cart-table">
                <div class="table-content table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th class="product-thumbnail">Product</th>
                                <th class="product-price">Price</th>
                                <th class="product-stock">stock status</th>
                                <th class="product-add-cart">Add to cart</th>
                                <th class="product-remove">Remove</th>
                               
                            </tr>
                        </thead>
                        <tbody>
                        <!-- wishlist foreach -->
                    <?php
                        foreach ($product->getData('wishlist') as $item) :
                        
                        $cart= $product->getProduct($item['item_id']); 
                    
                        $subTotal[] = array_map(function($item){ // array map function starts 
                        
                    ?>
                            <tr>
                                <td class="product-thumbnail  text-left">
                                    <!-- Single-product start -->
                                    <div class="single-product">
                                        <div class="product-img">
                                            <a href="single-product.php"><a href="single-product.php"><img src="<?php echo $item['item_image'] ?? "img/product/1.jpg" ?>" alt="" /></a></a>
                                        </div>
                                        <div class="product-info">
                                            <h4 class="post-title"><a class="text-light-black" href="#"><?php echo $item['item_name'] ?? "Unknown"; ?></a></h4>
                                            <p class="mb-0">Color :  Black</p>
                                            <p class="mb-0">Size : SL</p>
                                        </div>
                                    </div>
                                    <!-- Single-product end -->				
                                </td>
                                <td class="product-price">$<?php echo $item['item_price'] ?? "Unknown"; ?></td>
                                <td class="product-stock">in stock</td>
                                
                                    <!-- Add back to Cart  -->
                                <td class="product-add-cart">
                                    <form method="post">
                                            <input type="hidden" value="<?php echo $item['item_id'] ?? 0; ?>" name="item_id">
                                            <button type="submit" name="cart-submit" class="button"><i class="zmdi zmdi-shopping-cart-plus"></i></button>	
                                    </form>
                                </td>
                                <!-- Remove Products  -->
                                <td class="product-remove">
                                    <form method="post">
                                            <input type="hidden" value="<?php echo $item['item_id'] ?? 0; ?>" name="item_id">
                                            <button type="submit" name="delete-cart-submit" class="button"><i class="zmdi zmdi-close"></i></button>	
                                    </form>
                                </td>
                            </tr>
                        <?php
                            return $item['item_price'];
                        },$cart); // array map function ends 
                    
                        endforeach;	
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        								
    </div>
    <!-- wishlist end -->