<?php

shuffle($product_shuffle); 
?>

<!-- PURCHASE-ONLINE-AREA START -->
    <div class="purchase-online-area pt-80">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="section-title text-center">
								<h2 class="title-border">Purchase Online on CARPE DIEM</h2>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-12 text-center">
							<!-- Nav tabs -->
							<ul class="tab-menu clearfix">
								<li class="active"><a href="#new-arrivals" data-toggle="tab">New Arrivals</a></li>
								<li><a href="#best-seller"  data-toggle="tab">Best Seller </a></li>
								<li><a href="#most-view" data-toggle="tab">Most View </a></li>
								<li><a href="#discounts" data-toggle="tab">Discounts</a></li>
							</ul>
						</div>
						<div class="col-lg-12">
							<!-- Tab panes -->
							<div class="tab-content">
								<div class="tab-pane active" id="new-arrivals">
									<div class="row">
                                    <?php 
						                foreach ($product_shuffle as $item) :
                                       if ($item['item_id'] < 9) :
                                    ?>
										<!-- Single-product start -->
										<div class="single-product col-lg-3 col-md-4 col-sm-4 col-xs-12">
											<div class="product-img">
												<!-- <span class="pro-label new-label">new</span> -->
												<a href="<?php printf('%s?item_id=%s', 'single-product.php',  $item['item_id']); ?>"><img src="<?php echo $item['item_image'] ; ?>" alt="" /></a>
												
											</div>
											<div class="product-info clearfix">
												<div class="fix">
													<h4 class="post-title floatleft"><a href="<?php printf('%s?item_id=%s', 'single-product.php',  $item['item_id']); ?>"><?php echo  $item['item_name'] ?? "Unknown";  ?></a></h4>
													<p class="floatright hidden-sm">Furniture</p>
												</div>
												<div class="fix">
													<span class="pro-price floatleft">$<?php echo $item['item_price'] ?? '0' ; ?></span>
													<span class="pro-rating floatright">
														<a href="#"><i class="zmdi zmdi-star"></i></a>
														<a href="#"><i class="zmdi zmdi-star"></i></a>
														<a href="#"><i class="zmdi zmdi-star"></i></a>
														<a href="#"><i class="zmdi zmdi-star-half"></i></a>
														<a href="#"><i class="zmdi zmdi-star-half"></i></a>
													</span>
												</div>
											</div>
										</div>
										<!-- Single-product end -->
                                        <?php
                                        endif; 
                                        endforeach ;
                                         // closing foreach function ?>
										
									</div>
								</div>

                                
								<div class="tab-pane" id="best-seller">
                                <?php
                                shuffle($product_shuffle); 
                                ?>
                                <div class="row">
                                
                                    <?php 
						                foreach ($product_shuffle as $item) :
                                       if ($item['item_id'] < 9) :
                                    ?>
										<!-- Single-product start -->
										<div class="single-product col-lg-3 col-md-4 col-sm-4 col-xs-12">
											<div class="product-img">
												<!-- <span class="pro-label new-label">new</span> -->
												<a href="<?php printf('%s?item_id=%s', 'single-product.php',  $item['item_id']); ?>"><img src="<?php echo $item['item_image'] ; ?>" alt="" /></a>
												
											</div>
											<div class="product-info clearfix">
												<div class="fix">
													<h4 class="post-title floatleft"><a href="<?php printf('%s?item_id=%s', 'single-product.php',  $item['item_id']); ?>"><?php echo  $item['item_name'] ?? "Unknown";  ?></a></h4>
													<p class="floatright hidden-sm">Furniture</p>
												</div>
												<div class="fix">
													<span class="pro-price floatleft">$<?php echo $item['item_price'] ?? '0' ; ?></span>
													<span class="pro-rating floatright">
														<a href="#"><i class="zmdi zmdi-star"></i></a>
														<a href="#"><i class="zmdi zmdi-star"></i></a>
														<a href="#"><i class="zmdi zmdi-star"></i></a>
														<a href="#"><i class="zmdi zmdi-star-half"></i></a>
														<a href="#"><i class="zmdi zmdi-star-half"></i></a>
													</span>
												</div>
											</div>
										</div>
										<!-- Single-product end -->
                                        <?php
                                        endif; 
                                        endforeach ;
                                         // closing foreach function ?>
										
									</div>
								</div>
                                <div class="tab-pane" id="most-view">
                                <?php
                                shuffle($product_shuffle); 
                                ?>
                                <div class="row">
                                
                                    <?php 
						                foreach ($product_shuffle as $item) :
                                       if ($item['item_id'] < 9) :
                                    ?>
										<!-- Single-product start -->
										<div class="single-product col-lg-3 col-md-4 col-sm-4 col-xs-12">
											<div class="product-img">
												<!-- <span class="pro-label new-label">new</span> -->
												<a href="<?php printf('%s?item_id=%s', 'single-product.php',  $item['item_id']); ?>"><img src="<?php echo $item['item_image'] ; ?>" alt="" /></a>
												
											</div>
											<div class="product-info clearfix">
												<div class="fix">
													<h4 class="post-title floatleft"><a href="<?php printf('%s?item_id=%s', 'single-product.php',  $item['item_id']); ?>"><?php echo  $item['item_name'] ?? "Unknown";  ?></a></h4>
													<p class="floatright hidden-sm">Furniture</p>
												</div>
												<div class="fix">
													<span class="pro-price floatleft">$<?php echo $item['item_price'] ?? '0' ; ?></span>
													<span class="pro-rating floatright">
														<a href="#"><i class="zmdi zmdi-star"></i></a>
														<a href="#"><i class="zmdi zmdi-star"></i></a>
														<a href="#"><i class="zmdi zmdi-star"></i></a>
														<a href="#"><i class="zmdi zmdi-star-half"></i></a>
														<a href="#"><i class="zmdi zmdi-star-half"></i></a>
													</span>
												</div>
											</div>
										</div>
										<!-- Single-product end -->
                                        <?php
                                        endif; 
                                        endforeach ;
                                         // closing foreach function ?>
										
									</div>
								</div>
								<div class="tab-pane" id="discounts">
                                <?php
                                shuffle($product_shuffle); 
                                ?>
                                <div class="row">
                                
                                    <?php 
						                foreach ($product_shuffle as $item) :
                                       if ($item['item_id'] < 9) :
                                    ?>
										<!-- Single-product start -->
										<div class="single-product col-lg-3 col-md-4 col-sm-4 col-xs-12">
											<div class="product-img">
												<!-- <span class="pro-label new-label">new</span> -->
												<a href="<?php printf('%s?item_id=%s', 'single-product.php',  $item['item_id']); ?>"><img src="<?php echo $item['item_image'] ; ?>" alt="" /></a>
												
											</div>
											<div class="product-info clearfix">
												<div class="fix">
													<h4 class="post-title floatleft"><a href="<?php printf('%s?item_id=%s', 'single-product.php',  $item['item_id']); ?>"><?php echo  $item['item_name'] ?? "Unknown";  ?></a></h4>
													<p class="floatright hidden-sm">Furniture</p>
												</div>
												<div class="fix">
													<span class="pro-price floatleft">$<?php echo $item['item_price'] ?? '0' ; ?></span>
													<span class="pro-rating floatright">
														<a href="#"><i class="zmdi zmdi-star"></i></a>
														<a href="#"><i class="zmdi zmdi-star"></i></a>
														<a href="#"><i class="zmdi zmdi-star"></i></a>
														<a href="#"><i class="zmdi zmdi-star-half"></i></a>
														<a href="#"><i class="zmdi zmdi-star-half"></i></a>
													</span>
												</div>
											</div>
										</div>
										<!-- Single-product end -->
                                        <?php
                                        endif; 
                                        endforeach ;
                                         // closing foreach function ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- PURCHASE-ONLINE-AREA END -->