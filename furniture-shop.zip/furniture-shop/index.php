<!-- MASTER HEADER HERE  -->
<?php include ('master-header.php'); 
ob_start(); 
?>

	<body>
		<!-- WRAPPER START -->
		<div class="wrapper">
		<!-- HEADER HERE  -->
		<?php include('header.php'); ?>
		<!-- SLIDER-BANNER-AREA HERE --> 
		<?php include('template/_slider-banner.php'); ?>
		<!-- PRODUCT-AREA HERE -->
		<?php include('template/_product-area.php'); ?>
			<!-- DISCOUNT-PRODUCT START -->
			<div class="discount-product-area">
				<div class="container">
					<div class="row">
						<div class="discount-product-slider dots-bottom-right">
							<!-- single-discount-product start -->
							<div class="col-lg-12">
								<div class="discount-product">
									<img src="img/discount/1.jpg" alt="" />
									<div class="discount-img-brief">
										<div class="onsale">
											<span class="onsale-text">On Sale</span>
											<span class="onsale-price">$ 80.00</span>
										</div>
										<div class="discount-info">
											<h1 class="text-dark-red hidden-xs">Discount 50%</h1>
											<p class="hidden-xs">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed does eiusmodes tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim venim, quis nostrud exercitation ullamco laboris.</p>
											<a href="shop.php" class="button-one font-16px style-3 text-uppercase mt-5" data-text="Buy now">Buy now</a>
										</div>
									</div>
								</div>
							</div>
							<!-- single-discount-product end -->
							<!-- single-discount-product start -->
							<div class="col-lg-12">
								<div class="discount-product">
									<img src="img/discount/2.jpg" alt="" />
									<div class="discount-img-brief">
										<div class="onsale">
											<span class="onsale-text">On Sale</span>
											<span class="onsale-price">$ 80.00</span>
										</div>
										<div class="discount-info">
											<h1 class="text-dark-red hidden-xs">Discount 50%</h1>
											<p class="hidden-xs">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed does eiusmodes tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim venim, quis nostrud exercitation ullamco laboris.</p>
											<a href="shop.php" class="button-one font-16px style-3 text-uppercase mt-5" data-text="Buy now">Buy now</a>
										</div>
									</div>
								</div>
							</div>
							<!-- single-discount-product end -->
							<!-- single-discount-product start -->
							<div class="col-lg-12">
								<div class="discount-product">
									<img src="img/discount/3.jpg" alt="" />
									<div class="discount-img-brief">
										<div class="onsale">
											<span class="onsale-text">On Sale</span>
											<span class="onsale-price">$ 80.00</span>
										</div>
										<div class="discount-info">
											<h1 class="text-dark-red hidden-xs">Discount 50%</h1>
											<p class="hidden-xs">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed does eiusmodes tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim venim, quis nostrud exercitation ullamco laboris.</p>
											<a href="shop.php" class="button-one font-16px style-3 text-uppercase mt-5" data-text="Buy now">Buy now</a>
										</div>
									</div>
								</div>
							</div>
							<!-- single-discount-product end -->
							<!-- single-discount-product start -->
							<div class="col-lg-12">
								<div class="discount-product">
									<img src="img/discount/4.jpg" alt="" />
									<div class="discount-img-brief">
										<div class="onsale">
											<span class="onsale-text">On Sale</span>
											<span class="onsale-price">$ 80.00</span>
										</div>
										<div class="discount-info">
											<h1 class="text-dark-red hidden-xs">Discount 50%</h1>
											<p class="hidden-xs">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed does eiusmodes tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim venim, quis nostrud exercitation ullamco laboris.</p>
											<a href="shop.php" class="button-one font-16px style-3 text-uppercase mt-5" data-text="Buy now">Buy now</a>
										</div>
									</div>
								</div>
							</div>
							<!-- single-discount-product end -->
						</div>
					</div>
				</div>
			</div>
			<!-- DISCOUNT-PRODUCT END -->
			<?php include('template/_purchase.php'); ?>
			
			<!-- SUBSCRIVE-AREA START -->
			<div class="subscribe-area pt-80">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="subscribe">
								<form action="#">
									<input type="text" placeholder="Enter your email address"/>
									<button class="submit-button submit-btn-2 button-one" data-text="subscribe" type="submit" >subscribe</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- SUBSCRIVE-AREA END -->

		<!-- FOOTER BY PHP LINK  -->
			<?php include_once('footer.php'); ?>
			<?php include_once('master-footer.php'); ?>


 </html>	

	
